//
//  UICircularProgressRing.h
//  UICircularProgressRing
//
//  Created by Luis Padron on 9/13/16.
//  Copyright © 2016 Luis Padron. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UICircularProgressRing.
FOUNDATION_EXPORT double UICircularProgressRingVersionNumber;

//! Project version string for UICircularProgressRing.
FOUNDATION_EXPORT const unsigned char UICircularProgressRingVersionString[];



